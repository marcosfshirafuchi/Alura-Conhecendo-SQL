SELECT * from categorias;

SELECT * from fornecedores;

SELECT * from marcas;

SELECT COUNT(*) as Qtd_Categorias FROM categorias;

SELECT COUNT(*) as Qtd_Clientes  FROM clientes;

SELECT COUNT(*) as Qtd_Fornecedores  FROM fornecedores;

SELECT COUNT(*) as Qtd_ItensVenda  FROM itens_venda;

SELECT COUNT(*) as Qtd_Marcas  FROM marcas;

SELECT COUNT(*) as Qtd_Produtos  from produtos;

SELECT COUNT(*) as Qtd_Vendas  from vendas;